<?xml version="1.0"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>


    <title>WebAndVetted</title>


    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}
.style2 {
	font-size: medium;
	font-weight: bold;
}
-->
    </style>
</head>

<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">

<?php
include "Header.php"
?>
<?php
include "menu.php"
?>
<!-- Page (2 columns) -->
    <div id="page" class="box">
    <div id="page-in" class="box">

        <div id="strip" class="box noprint">

            <!-- RSS feeds -->
            <hr class="noscreen" />

            <!-- Breadcrumbs -->
            <p id="breadcrumbs">&nbsp;</p>
          <hr class="noscreen" />

        </div> <!-- /strip -->

        <!-- Content -->
        <div id="content">


            <!-- /article -->

            <hr class="noscreen" />


            <!-- /article -->

            <hr class="noscreen" />

            <!-- Article -->

            <!-- /article -->

            <hr class="noscreen" />

            <!-- Article -->
            <div class="article">
                <h2><span><a>HOW IT WORKS</a></span></h2>
			
				<p align="right"> <img src="design/capture.png" alt="" width="470" height="160" /></p>
                <p> <span class="style2">S</span>eat back and enjoy the  (5 star) rated webservice provider <img src="design/rate.png" width="44" height="14" /></p>
             
				
                <table width="100%" border="0">
                  <tr>
                    <td><div align="center"><img src="design/Post.png" alt="" width="64" height="64" /></div></td>
                    <td><div align="center"><img src="design/come.png" alt="" width="64" height="64" /></div></td>
                    <td><div align="center"><img src="design/collabo.png" alt="" width="64" height="64" /></div></td>
                  </tr>
                  <tr>
                    <td bgcolor="#A0B9F3"><div align="center"><a><strong>POST A JOB (IT'S FREE)</strong></a></div></td>
                    <td bgcolor="#A0B9F3"><div align="center"><a><strong>FREELANCERS COME TO YOU</strong></a></div></td>
                    <td bgcolor="#A0B9F3"><div align="center"><a><strong>COLLABORATE EASILY</strong></a></div></td>
                  </tr>
                
                </table>
				<p>We give you the platfom to post a job for free and let freelancers ,in addition companies to view them.Its easy for freelancers to detect you with us</p>
				<p>Collaboration between clients and webservice providers is at a 5 star rate </p>
			
			  
			  


          </div> <!-- /article -->

            <hr class="noscreen" />

        </div> <!-- /content -->

<?php
include "right.php"
?>

    </div> <!-- /page-in -->
    </div> <!-- /page -->


<?php
include "footer.php"
?>
</div> <!-- /main -->

</body>
</html>
