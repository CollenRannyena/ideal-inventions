<!DOCTYPE html>
<html>
<head>

<title>Untitled Document</title>
</head>

<body>
<?php
$Id = $_GET['Id'];
$Email = $_GET['Email'];
// Establish Connection with MYSQL
$con = mysqli_connect("localhost","root");
// Select Database
mysqli_select_db($con,"job");
// Specify the query to Update Record
$sql = "Update Application_Master set Status='Call Latter Send' where ApplicationId=".$Id."";
// Execute query
mysqli_query($con,$sql);
// Close The Connection
mysqli_close($con);
echo '<script type="text/javascript">alert("Updated Succesfully");window.location=\'Application.php\';</script>';
?>
</body>
</html>
