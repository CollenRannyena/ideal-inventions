<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Profile.php">Profile<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageJob.php">Manage Job<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageWalkin.php">Manage Walkin<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Application.php">Application<span class="tab-l"></span><span class="tab-r"></span></a></li>
                
                <li><a href="Logout.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
				
				<p>Date/Time: <span id="datetime"></span></p>
				<script>
				var dt = new Date();
				document.getElementById("datetime").innerHTML = (("0"+dt.getDate()).slice(-2)) +"."+ (("0"+(dt.getMonth()+1)).slice(-2)) +"."+ (dt.getFullYear()) +" "+ (("0"+dt.getHours()).slice(-2)) +":"+ (("0"+dt.getMinutes()).slice(-2));
				</script>
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->